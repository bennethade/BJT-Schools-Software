@extends('layouts.app')
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-12">
                    {{-- <h1>UNDER DEVELOPMENT</h1> --}}
                    </div>
                </div>
            </div>
        </section>
        <!-- Main content -->
        
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card card-primary" style="padding: 20px;">
                            <h2 style="color: blue">This Page Is Still Undergoing Development!</h2>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>


@endsection